# DB1-BCC
Repositório criado para o trabalho final da matéria de Banco de dados

Alunos:
Alan Lima Marques,
João Vitor Zavatin (Lider),
Lucas Patrick,
