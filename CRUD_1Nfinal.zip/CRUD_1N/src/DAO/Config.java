package DAO;

/**
 *
 * @author André Schwerz
 */
public class Config {
    public static final String URL = "jdbc:mysql://localhost/Filme?useSSL=false";
    public static final String LOGIN = "root";
    public static final String PASSWORD = "root"; 
    //public static final String PASSWORD = null; 
}