/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

/**
 *
 * @author alan
 */
public class PassaString {
    String string;
    
    public void setString(String string){
        this.string=string;
    }
    
    public String getString(){
        return string;
    }
    
}
