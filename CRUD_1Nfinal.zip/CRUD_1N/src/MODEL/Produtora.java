package MODEL;

import java.util.Date;
import MODEL.Pais;
import java.text.SimpleDateFormat;

/**
 *
 * @author André Schwerz
 */
public class Produtora {
    
    private String nome;
    
    private Pais pais;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Pais getPais() {
        return pais;
    }

    public void setPais(Pais pais) {
        this.pais = pais;
    }
    
    
    
    
}
