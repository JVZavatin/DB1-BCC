package MODEL;

/**
 *
 * @author André Schwerz
 */
public class Genero {

    private String idGenero;
    private String Descricao;
    //private String nome;
    //private boolean status;
    //private String cidade;
    //private String estilo;

    public String getIdGenero() {
        return idGenero;
    }

    public void setIdGenero(String idGenero) {
        this.idGenero = idGenero;
    }

    public String getDescricao() {
        return Descricao;
    }

    public void setDescricao(String Descricao) {
        this.Descricao = Descricao;
    }

}
